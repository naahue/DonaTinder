from django.shortcuts import render,redirect
from django.contrib.auth import login,authenticate,logout
from .forms import *
from django.contrib.auth.decorators import login_required

# Create your views here.
def registrar(request):
    if request.user.is_authenticated:
        return redirect('donacion:ingresarDonacion')
    
    if request.method=='POST':
        form=RegistroForm(request.POST)
        if form.is_valid():
            form.save()
            user = authenticate(
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password1'],
            )
            if user is not None:
                user.save()
                login(request, user)
                return redirect('donacion:ingresarDonacion')
            else:
                message = 'Error al querer iniciar sesión. Intentelo nuevamente.'
                print('Error al querer iniciar sesión. Intentelo nuevamente.')
        else:
            for error in form.errors.values():
                print(error)
    else:
        form=RegistroForm()
    
    context={
        'form':form
        }
    return render(request,'usuarios/registro.html',context)

def inicioSesion(request):
    message=None
    if request.method == 'POST':
        form = InicioSesionForm(request.POST)
        if form.is_valid():
            user = authenticate(
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password'],
            )
            if user is not None:
                login(request, user)
                return redirect('donacion:ingresarDonacion')
                #message = f'Hello {user.username}! You have been logged in'
            else:
                message = 'Error con el usuario o la contraseña'
                print('Error con el usuario o la contraseña')
    else:
        form=InicioSesionForm()
    context={
            'form':form,
            'message':message
            }
    return render(request, 'usuarios/inicioSesion.html', context)

@login_required
def salir(request):
    if request.user.is_authenticated:
        logout(request)
        return redirect("usuarios:inicioSesion")
    else:
        return redirect('donacion:ingresarDonacion')

@login_required
def modificar(request):
    if request.user.is_authenticated:
        if request.method=='POST':
            form=ModificarDatosForm(request.POST)
            if form.is_valid():
                request.user.first_name=form.cleaned_data['first_name']
                request.user.last_name=form.cleaned_data['last_name']
                request.user.save()
                return redirect('donacion:ingresarDonacion')
            else:
                for error in form.errors.values():
                    print(error)
        else:
            form=ModificarDatosForm()
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'form':form,
            }
    return render(request, 'usuarios/modificarDatos.html', context)

@login_required
def modificarContraseña(request):
    if request.user.is_authenticated:
        if request.method=='POST':
            form=ModificarContraseñaForm(request.POST)
            if form.is_valid():
                request.user.set_password(form.cleaned_data['password1'])                
                request.user.save()
                login(request,request.user)
                return redirect('donacion:ingresarDonacion')
            else:
                for error in form.errors.values():
                    print(error)
        else:
            form=ModificarContraseñaForm()
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'form':form,
            }
    return render(request, 'usuarios/modificarContraseña.html', context)

@login_required
def eliminarCuenta(request):
    if request.user.is_authenticated:
        if request.method=='POST':
            request.user.delete()
            logout(request)            
            return redirect("usuarios:inicioSesion")
        else:
            return render(request, 'usuarios/eliminarCuenta.html')