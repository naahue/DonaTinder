from django.db import models
from usuarios.models import CustomUser

# Create your models here.

ELECCION_ESTADO=[
    (1,'Nuevo'),
    (2,'Usado'),
    (3,'Dañado')
]

ELECCION_RETIRADO=[
    (0,'Sin retirar'),
    (1,'Retirado')
]

class Donacion(models.Model):
    id=models.IntegerField(primary_key=True)
    nombre=models.CharField(max_length=20)
    estado=models.IntegerField(choices=ELECCION_ESTADO,default=1,null=False,blank=False)
    descripcion=models.CharField(max_length=200)
    imagen=models.ImageField(upload_to='imagenes/')
    donador=models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    retirado=models.IntegerField(choices=ELECCION_RETIRADO,default=0,null=False,blank=False)
