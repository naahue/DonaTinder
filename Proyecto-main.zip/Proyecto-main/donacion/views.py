from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from .forms import IgresarDonacionForm
from .forms import ModificarDonacionForm
from .models import Donacion
#from django.views.generic.edit import CreateView

# Create your views here.
@login_required
def ingresarDonacion(request):
    if request.user.is_authenticated:
        if request.method=='POST':
            form=IgresarDonacionForm(request.POST,request.FILES)
            if form.is_valid():
                donacion = form.save(commit=False)
                donacion.donador=request.user
                donacion.save()
                return redirect("donacion:ingresarDonacion")
            else:
                for error in form.errors.values():
                    print(error)
        else:
            form=IgresarDonacionForm()
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'form':form,
            }
    return render(request,'donacion/ingresarDonacion.html',context)

@login_required
def verDonaciones(request,userId):
    if request.user.is_authenticated:
        if request.method=='GET':
            donacion=Donacion.objects.filter(donador_id=userId,retirado=0).all()
        else:
            return redirect("donacion:ingresarDonacion")
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'donaciones':donacion,
            }
    return render(request, 'donacion/verDonaciones.html',context)

@login_required
def confirmarDonacion(request,donacionId):
    if request.user.is_authenticated:
        if request.method=='POST':
            donacion=Donacion.objects.filter(id=donacionId).get()
            donacion.retirado=1
            donacion.save()
            return redirect("donacion:verDonaciones",userId=request.user.id)
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'donacion':Donacion.objects.filter(id=donacionId).get(),
            }
    return render(request, 'donacion/confirmarDonacion.html',context)

@login_required
def ayuda(request):
    return render(request, 'donacion/ayuda.html')

@login_required
def modificarDonacion(request,donacionId):
    if request.user.is_authenticated:
        if request.method=='POST':
            form=ModificarDonacionForm(request.POST,request.FILES)
            if form.is_valid():
                donacion=Donacion.objects.filter(id=donacionId).get()
                #donacion = form.save(commit=False)
                donacion.nombre=form.cleaned_data['nombre']
                donacion.estado=form.cleaned_data['estado']
                donacion.descripcion=form.cleaned_data['descripcion']
                donacion.save()
                return redirect("donacion:verDonaciones",userId=request.user.id)
            else:
                for error in form.errors.values():
                    print(error)
        else:
            form=ModificarDonacionForm()
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'form':form,
            }
    return render(request,'donacion/modificarDonacion.html',context)

@login_required
def eliminarDonacion(request,donacionId):
    if request.user.is_authenticated:
        if request.method=='POST':
            donacion=Donacion.objects.filter(id=donacionId).get()
            donacion.eliminado=1
            donacion.delete()
            return redirect("donacion:verDonaciones",userId=request.user.id)
    else:
        return redirect("usuarios:inicioSesion")
    context={
            'donacion':Donacion.objects.filter(id=donacionId).get(),
            }
    return render(request, 'donacion/eliminarDonacion.html',context)
